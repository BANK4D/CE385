import type { RequestHandler } from "express";
import type { ZodError, ZodType } from "zod";

interface Schemas {
  params?: ZodType;
  query?: ZodType;
  body?: ZodType;
}

const STATUS_OF: Record<keyof Schemas, number> = { params: 400, query: 400, body: 422 };

export function validate(schemas: Schemas): RequestHandler {
  return (req, res, next) => {
    const valid: Record<string, unknown> = {};

    for (const source of ["params", "query", "body"] as const) {
      const schema = schemas[source];
      if (!schema) continue;

      const result = schema.safeParse(req[source]);

      if (!result.success) {
        (result.error as ZodError & { httpStatus?: number }).httpStatus = STATUS_OF[source];
        next(result.error);
        return;
      }

      valid[source] = result.data;
    }

    res.locals.valid = valid;
    next();
  };
}